package com.conferencePlanner.conferenceplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConferenceplannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConferenceplannerApplication.class, args);
	}

}
